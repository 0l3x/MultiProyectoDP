package olex.physiocareapifx.model;

import java.util.List;

public class PhysioResponse extends BaseResponse {
    private List<Physio> resultado;

    public List<Physio> getResultado() {
        return resultado;
    }
}